from setuptools import setup, find_packages

setup(
    name='database',
    version='1.2.0',
    description='A common Django app for sharing functionality',
    author='i am',
    author_email='siva@gmail.com',
    packages=find_packages(),
    install_requires=[
        'Django',
        
    ],
)
